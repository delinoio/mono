package main

import (
	"fmt"
	"os"
	"os/signal"
	"syscall"

	"github.com/delinoio/mono/cmds/ownsand-guest/guestlisten"
)

func main() {
	stop := make(chan os.Signal, 1)
	signal.Notify(stop, syscall.SIGTERM)
	listener, err := guestlisten.Listen("unix://g.sock")
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	fmt.Println("listening")
	<-stop
	if err := listener.Close(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
