import argparse
from contextlib import contextmanager
import fcntl
import os
from pathlib import Path
import select
import signal
import socket
import stat
import subprocess
import sys
import tempfile
import time

SOCKET = Path("g.sock")
SIDECAR = Path("g.sock.lock")
TIMEOUT = "wait for the unix socket path lock timed out"
DENIED = "lock unix socket path failed: permission denied"


def identity(info):
    return info.st_dev, info.st_ino


def check_mode(mode):
    info = SIDECAR.lstat()
    assert stat.S_ISREG(info.st_mode) and info.st_uid == os.geteuid()
    assert stat.S_IMODE(info.st_mode) == mode, oct(info.st_mode)
    return identity(info)


class Probe:
    def __init__(self, helper, listener):
        self.helper = helper
        self.listener = listener
        self.launches = 0

    @contextmanager
    def start(self, mask="0077", listen_only=False):
        self.launches += 1
        cmd = [self.listener] if listen_only else [
            self.helper, "--listen", "unix://g.sock", "--clock", "ignore",
            "--grow-disk=false", "--state-dir", f"state-{self.launches}",
        ]
        env = {k: v for k, v in os.environ.items() if not k.startswith(("OWNSAND_", "OTEL_"))}
        child = subprocess.Popen(
            ["/bin/sh", "-c", 'umask "$1"; shift; exec "$@"', "guestlisten-probe", mask, *cmd],
            stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, env=env,
        )
        try:
            yield child
        finally:
            if child.poll() is None:
                child.send_signal(signal.SIGCONT)
                child.terminate()
                try:
                    child.communicate(timeout=3)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.communicate()

    @staticmethod
    def ready(child):
        deadline = time.monotonic() + 4
        while time.monotonic() < deadline:
            if child.poll() is not None:
                raise AssertionError(f"helper exited early ({child.returncode}): {child.communicate()[0]}")
            try:
                with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
                    client.connect(str(SOCKET))
                return
            except (FileNotFoundError, ConnectionRefusedError):
                time.sleep(0.01)
        raise AssertionError("helper did not bind")

    @staticmethod
    def clean_stop(child):
        child.terminate()
        output, _ = child.communicate(timeout=4)
        assert child.returncode == 0, (child.returncode, output)
        assert not SOCKET.exists()

    @staticmethod
    def check_failure(child, diagnostic):
        output, _ = child.communicate(timeout=12)
        assert child.returncode == 1, (child.returncode, output)
        assert "listen failed" in output and diagnostic in output.lower(), output
        assert str(SOCKET) not in output, output

    def umasks(self):
        lock_id = None
        for mask in ("0200", "0200", "0077"):
            # Exercise the production listener under 0200 without involving
            # the unrelated state-directory creation done by the full helper.
            with self.start(mask=mask, listen_only=True) as child:
                assert select.select([child.stdout], [], [], 4)[0], "listener did not report readiness"
                line = child.stdout.readline().strip()
                assert line == "listening", line
                assert stat.S_ISSOCK(SOCKET.lstat().st_mode)
                self.clean_stop(child)
            inode = check_mode(0o600)
            assert lock_id is None or lock_id == inode
            lock_id = inode
        print("umasks 0200, 0200, 0077: all bound and retained the same 0600 sidecar")

    def contention(self):
        lock_id = check_mode(0o600)
        first_socket = make_stale()
        with SIDECAR.open("r+b") as sidecar:
            for release_in_budget in (False, True):
                fcntl.flock(sidecar, fcntl.LOCK_EX)
                with self.start() as child:
                    started = time.monotonic()
                    if release_in_budget:
                        time.sleep(0.2)
                        assert child.poll() is None
                        assert identity(SOCKET.lstat()) == first_socket
                        fcntl.flock(sidecar, fcntl.LOCK_UN)
                        self.ready(child)
                        elapsed = time.monotonic() - started
                        self.clean_stop(child)
                        print(f"in-budget waiter: rebound the stale socket in {elapsed:.3f}s")
                    else:
                        self.check_failure(child, TIMEOUT)
                        elapsed = time.monotonic() - started
                        assert elapsed >= 4.99, elapsed
                        assert identity(SOCKET.lstat()) == first_socket
                        fcntl.flock(sidecar, fcntl.LOCK_UN)
                        print(f"held lock: waiter timed out in {elapsed:.3f}s, stale socket inode unchanged")
        assert check_mode(0o600) == lock_id

    def permissions(self):
        lock_id = check_mode(0o600)
        first_socket = make_stale()
        SIDECAR.chmod(0o400)
        with self.start() as child:
            self.check_failure(child, DENIED)
        assert identity(SOCKET.lstat()) == first_socket
        assert check_mode(0o400) == lock_id
        SIDECAR.chmod(0o600)
        with self.start() as child:
            self.ready(child)
            self.clean_stop(child)
        assert check_mode(0o600) == lock_id
        print("legacy sidecar: path-free access failure, then recovery on the same inode after chmod")

        with SIDECAR.open("r+b") as sidecar:
            fcntl.flock(sidecar, fcntl.LOCK_EX)
            os.fchmod(sidecar.fileno(), 0o400)
            first_socket = make_stale()
            with self.start() as child:
                time.sleep(0.2)
                assert child.poll() is None and check_mode(0o400) == lock_id
                os.fchmod(sidecar.fileno(), 0o600)
                time.sleep(0.2)
                assert child.poll() is None and identity(SOCKET.lstat()) == first_socket
                fcntl.flock(sidecar, fcntl.LOCK_UN)
                self.ready(child)
                self.clean_stop(child)
        assert check_mode(0o600) == lock_id
        print("creator restored access in place: waiter bound after the same sidecar lock was released")

    def delayed_wake(self, baseline=False):
        if not SIDECAR.exists():
            SIDECAR.touch(mode=0o600)
        first_socket = make_stale()
        with SIDECAR.open("r+b") as sidecar:
            fcntl.flock(sidecar, fcntl.LOCK_EX)
            with self.start() as child:
                started = time.monotonic()
                wait_for_sidecar(child, identity(os.fstat(sidecar.fileno())))
                child.send_signal(signal.SIGSTOP)
                time.sleep(max(0, 5.15 - (time.monotonic() - started)))
                assert identity(SOCKET.lstat()) == first_socket
                fcntl.flock(sidecar, fcntl.LOCK_UN)
                child.send_signal(signal.SIGCONT)
                if baseline:
                    self.ready(child)
                    self.clean_stop(child)
                    print("baseline delayed wake: reproduced a successful bind after 5.15s")
                    return
                self.check_failure(child, TIMEOUT)
                assert identity(SOCKET.lstat()) == first_socket
                print("delayed wake: resumed after 5.15s, timed out and preserved the stale socket inode")
        with self.start() as child:
            self.ready(child)
            self.clean_stop(child)
        print("subsequent helper: bound after the delayed waiter timed out")


def make_stale():
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as listener:
        listener.bind(str(SOCKET))
    return identity(SOCKET.lstat())


def wait_for_sidecar(child, inode):
    deadline = time.monotonic() + 2
    while time.monotonic() < deadline:
        assert child.poll() is None, child.communicate()[0]
        for fd in Path(f"/proc/{child.pid}/fd").iterdir():
            try:
                if identity(fd.stat()) == inode:
                    return
            except FileNotFoundError:
                pass
        time.sleep(0.005)
    raise AssertionError("helper did not open the contended sidecar")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--helper", type=Path, required=True)
    parser.add_argument("--listener", type=Path)
    parser.add_argument("--scratch", type=Path, required=True)
    parser.add_argument("--baseline", action="store_true")
    args = parser.parse_args()
    assert os.geteuid() != 0, "run as a non-root account"
    helper = args.helper.resolve(strict=True)
    listener = args.listener.resolve(strict=True) if args.listener else None
    original = Path.cwd()
    with tempfile.TemporaryDirectory(prefix="guestlisten-", dir=args.scratch.resolve(strict=True)) as scratch:
        if sys.platform == "darwin":
            subprocess.run(["/bin/chmod", "-N", scratch], check=True)
            subprocess.run(["/bin/ls", "-lde", scratch], check=True)
        os.chdir(scratch)
        try:
            probe = Probe(helper, listener)
            if args.baseline:
                assert sys.platform == "linux"
                probe.delayed_wake(baseline=True)
                return
            assert listener is not None
            probe.umasks()
            probe.contention()
            probe.permissions()
            if sys.platform == "linux":
                probe.delayed_wake()
        finally:
            os.chdir(original)


if __name__ == "__main__":
    main()
